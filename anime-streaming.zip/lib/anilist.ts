// AniList GraphQL API client

// Base URL for AniList API
const ANILIST_API = "https://graphql.anilist.co"

// GraphQL query to fetch trending anime
export const TRENDING_ANIME_QUERY = `
  query {
    Page(page: 1, perPage: 10) {
      media(sort: TRENDING_DESC, type: ANIME) {
        id
        title {
          romaji
          english
          native
        }
        description
        coverImage {
          large
          medium
        }
        bannerImage
        format
        status
        episodes
        genres
        averageScore
        season
        seasonYear
        nextAiringEpisode {
          episode
          airingAt
        }
      }
    }
  }
`

// GraphQL query to fetch anime details by ID
export const ANIME_DETAILS_QUERY = `
  query ($id: Int) {
    Media(id: $id, type: ANIME) {
      id
      title {
        romaji
        english
        native
      }
      description
      coverImage {
        large
        extraLarge
      }
      bannerImage
      format
      status
      episodes
      duration
      genres
      averageScore
      popularity
      season
      seasonYear
      studios {
        nodes {
          name
        }
      }
      nextAiringEpisode {
        episode
        airingAt
      }
      relations {
        edges {
          relationType
          node {
            id
            title {
              romaji
              english
            }
            coverImage {
              medium
            }
            format
            type
            status
          }
        }
      }
    }
  }
`

// GraphQL query to search for anime
export const SEARCH_ANIME_QUERY = `
  query ($search: String) {
    Page(page: 1, perPage: 20) {
      media(search: $search, type: ANIME, sort: POPULARITY_DESC) {
        id
        title {
          romaji
          english
          native
        }
        coverImage {
          medium
        }
        format
        status
        episodes
        seasonYear
      }
    }
  }
`

// Function to fetch data from AniList API
export async function fetchFromAniList(query: string, variables = {}) {
  try {
    const response = await fetch(ANILIST_API, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
      },
      body: JSON.stringify({
        query,
        variables,
      }),
      cache: "force-cache",
      next: { revalidate: 3600 }, // Cache for 1 hour
    })

    const json = await response.json()
    return json.data
  } catch (error) {
    console.error("Error fetching from AniList:", error)
    throw error
  }
}

// Helper function to format anime data
export function formatAnimeData(anime: any) {
  return {
    id: anime.id,
    title: anime.title.english || anime.title.romaji,
    originalTitle: anime.title.native,
    description: anime.description ? anime.description.replace(/<[^>]*>/g, "") : "",
    coverImage: anime.coverImage.large || anime.coverImage.medium,
    bannerImage: anime.bannerImage,
    format: anime.format,
    status: anime.status,
    episodes: anime.episodes,
    currentEpisode: anime.nextAiringEpisode ? anime.nextAiringEpisode.episode - 1 : anime.episodes,
    genres: anime.genres,
    score: anime.averageScore,
    season: anime.season,
    year: anime.seasonYear,
    studios: anime.studios?.nodes?.map((studio: any) => studio.name) || [],
    duration: anime.duration ? `${anime.duration} min per ep` : "Unknown",
    nextEpisodeDate: anime.nextAiringEpisode ? new Date(anime.nextAiringEpisode.airingAt * 1000) : null,
  }
}

// Function to get trending anime
export async function getTrendingAnime() {
  const data = await fetchFromAniList(TRENDING_ANIME_QUERY)
  return data.Page.media.map(formatAnimeData)
}

// Function to get anime details by ID
export async function getAnimeDetails(id: number) {
  const data = await fetchFromAniList(ANIME_DETAILS_QUERY, { id })
  return formatAnimeData(data.Media)
}

// Function to search for anime
export async function searchAnime(query: string) {
  const data = await fetchFromAniList(SEARCH_ANIME_QUERY, { search: query })
  return data.Page.media.map(formatAnimeData)
}

