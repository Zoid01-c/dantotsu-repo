// External anime sources manager

// Define the structure for a video source
export interface VideoSource {
  url: string
  quality: string
  type: string
}

// Define the structure for a subtitle track
export interface SubtitleTrack {
  url: string
  lang: string
  label: string
}

// Define the structure for a streaming source provider
export interface SourceProvider {
  id: string
  name: string
  url: string
  isWorking: boolean
}

// List of external streaming sources
export const EXTERNAL_SOURCES: SourceProvider[] = [
  {
    id: "hianime",
    name: "HiAnime",
    url: "https://hianime.to",
    isWorking: true,
  },
  {
    id: "aniplaynow",
    name: "AniPlayNow",
    url: "https://aniplaynow.live",
    isWorking: true,
  },
  {
    id: "9anime",
    name: "9AnimeTV",
    url: "https://9animetv.to",
    isWorking: true,
  },
  {
    id: "animeheaven",
    name: "AnimeHeaven",
    url: "https://animeheaven.me",
    isWorking: true,
  },
  {
    id: "retrocrush",
    name: "RetroCrush",
    url: "https://www.retrocrush.tv",
    isWorking: true,
  },
  {
    id: "allmanga",
    name: "AllManga",
    url: "https://allmanga.to",
    isWorking: true,
  },
]

// Function to generate a search URL for a specific source
export function getSourceSearchUrl(sourceId: string, query: string): string {
  const source = EXTERNAL_SOURCES.find((s) => s.id === sourceId)
  if (!source) return ""

  const encodedQuery = encodeURIComponent(query)

  switch (sourceId) {
    case "hianime":
      return `${source.url}/search?keyword=${encodedQuery}`
    case "aniplaynow":
      return `${source.url}/search?q=${encodedQuery}`
    case "9anime":
      return `${source.url}/search?keyword=${encodedQuery}`
    case "animeheaven":
      return `${source.url}/search.html?keyword=${encodedQuery}`
    case "retrocrush":
      return `${source.url}/search?q=${encodedQuery}`
    case "allmanga":
      return `${source.url}/search?q=${encodedQuery}`
    default:
      return `${source.url}/search?q=${encodedQuery}`
  }
}

// Function to get the available sources for an anime
export async function getAvailableSources(animeTitle: string): Promise<SourceProvider[]> {
  // In a real implementation, you would check which sources have this anime
  // For demo purposes, we'll return all sources
  return EXTERNAL_SOURCES
}

// Function to normalize anime title for better matching with external sources
export function normalizeTitle(title: string): string {
  return title
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, " ")
    .trim()
    .replace(/\s+/g, "-")
}

