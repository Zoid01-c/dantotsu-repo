"use client"

import { useState, useEffect } from "react"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Play, Volume2 } from "lucide-react"
import Link from "next/link"
import { Skeleton } from "@/components/ui/skeleton"

interface Anime {
  id: number
  title: string
  description: string
  coverImage: string
  bannerImage: string
  status: string
  currentEpisode: number
  year: number
}

export default function FeaturedAnime() {
  const [muted, setMuted] = useState(true)
  const [featuredAnime, setFeaturedAnime] = useState<Anime | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    async function fetchFeaturedAnime() {
      try {
        const response = await fetch("/api/trending")
        const data = await response.json()

        if (data.anime && data.anime.length > 0) {
          // Select the first trending anime as featured
          setFeaturedAnime(data.anime[0])
        }
      } catch (error) {
        console.error("Error fetching featured anime:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchFeaturedAnime()
  }, [])

  if (loading) {
    return (
      <div className="relative w-full h-[500px] rounded-xl overflow-hidden mb-8 bg-card/50">
        <Skeleton className="h-full w-full" />
        <div className="absolute bottom-0 left-0 p-6 z-20 w-full">
          <Skeleton className="h-6 w-32 mb-2" />
          <Skeleton className="h-10 w-3/4 mb-2" />
          <Skeleton className="h-4 w-64 mb-4" />
          <Skeleton className="h-20 w-full mb-4" />
          <div className="flex gap-3">
            <Skeleton className="h-10 w-32" />
            <Skeleton className="h-10 w-10" />
          </div>
        </div>
      </div>
    )
  }

  if (!featuredAnime) {
    return null
  }

  return (
    <div className="relative w-full h-[500px] rounded-xl overflow-hidden mb-8">
      <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent z-10" />

      <Image
        src={featuredAnime.bannerImage || featuredAnime.coverImage || "/placeholder.svg?height=500&width=1000"}
        alt={featuredAnime.title}
        fill
        className="object-cover"
        priority
      />

      <div className="absolute bottom-0 left-0 p-6 z-20 w-full">
        <div className="text-pink-500 font-semibold mb-2">#1 Trending</div>
        <h2 className="text-4xl font-bold text-white mb-2">{featuredAnime.title}</h2>

        <div className="flex items-center gap-4 mb-4">
          <div className="flex items-center">
            <span className="bg-white text-black px-2 py-0.5 text-xs font-bold rounded">TV</span>
            <span className="ml-2 text-green-400 text-sm">{featuredAnime.status}</span>
          </div>
          <div className="text-white/80 text-sm">{featuredAnime.year}</div>
          <div className="text-white/80 text-sm">Episode {featuredAnime.currentEpisode}</div>
        </div>

        <p className="text-white/80 max-w-2xl mb-4">
          {featuredAnime.description?.substring(0, 250)}
          {featuredAnime.description?.length > 250 ? "..." : ""}
        </p>

        <div className="flex gap-3">
          <Button asChild className="bg-purple-600 hover:bg-purple-700">
            <Link href={`/watch/${featuredAnime.id}/${featuredAnime.currentEpisode}`}>
              <Play className="mr-2 h-4 w-4" />
              Watch Now
            </Link>
          </Button>
          <Button variant="outline" size="icon" onClick={() => setMuted(!muted)}>
            <Volume2 className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </div>
  )
}

