"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import Image from "next/image"
import { Card, CardContent } from "@/components/ui/card"
import { Skeleton } from "@/components/ui/skeleton"

interface RelatedAnime {
  id: number
  title: string
  coverImage: string
  format: string
  year: number
}

interface RelatedAnimeProps {
  animeId?: number
}

export default function RelatedAnime({ animeId }: RelatedAnimeProps) {
  const [relatedAnime, setRelatedAnime] = useState<RelatedAnime[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    async function fetchRelatedAnime() {
      try {
        // In a real implementation, you would fetch related anime from your API
        // For demo purposes, we'll use mock data

        // Simulate API call
        await new Promise((resolve) => setTimeout(resolve, 1000))

        const mockRelatedAnime = [
          {
            id: 1,
            title: "Dr. STONE",
            coverImage: "/placeholder.svg?height=120&width=80",
            format: "TV",
            year: 2019,
          },
          {
            id: 2,
            title: "Dr. STONE: Stone Wars",
            coverImage: "/placeholder.svg?height=120&width=80",
            format: "TV",
            year: 2021,
          },
          {
            id: 3,
            title: "Dr. STONE: New World",
            coverImage: "/placeholder.svg?height=120&width=80",
            format: "TV",
            year: 2023,
          },
          {
            id: 4,
            title: "Science Fell in Love, So I Tried to Prove It",
            coverImage: "/placeholder.svg?height=120&width=80",
            format: "TV",
            year: 2020,
          },
        ]

        setRelatedAnime(mockRelatedAnime)
      } catch (error) {
        console.error("Error fetching related anime:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchRelatedAnime()
  }, [animeId])

  if (loading) {
    return (
      <div className="space-y-3">
        {[...Array(4)].map((_, index) => (
          <Skeleton key={index} className="h-24 w-full" />
        ))}
      </div>
    )
  }

  return (
    <div className="space-y-3">
      {relatedAnime.map((anime) => (
        <Link href={`/anime/${anime.id}`} key={anime.id}>
          <Card className="overflow-hidden hover:bg-accent transition-colors">
            <CardContent className="p-3">
              <div className="flex gap-3">
                <div className="relative w-16 h-24 flex-shrink-0">
                  <Image
                    src={anime.coverImage || "/placeholder.svg"}
                    alt={anime.title}
                    fill
                    className="object-cover rounded-sm"
                  />
                </div>
                <div className="flex flex-col justify-center">
                  <h3 className="font-medium line-clamp-2">{anime.title}</h3>
                  <p className="text-xs text-muted-foreground">
                    {anime.format} • {anime.year}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </Link>
      ))}
    </div>
  )
}

