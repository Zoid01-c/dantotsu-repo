"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import Image from "next/image"
import { Card } from "@/components/ui/card"
import { Skeleton } from "@/components/ui/skeleton"

interface Anime {
  id: number
  title: string
  coverImage: string
  status: string
  currentEpisode: number
  format: string
}

export default function TrendingSection() {
  const [trendingAnime, setTrendingAnime] = useState<Anime[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    async function fetchTrendingAnime() {
      try {
        const response = await fetch("/api/trending")
        const data = await response.json()

        if (data.anime) {
          // Skip the first one as it's used in the featured section
          setTrendingAnime(data.anime.slice(1))
        }
      } catch (error) {
        console.error("Error fetching trending anime:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchTrendingAnime()
  }, [])

  if (loading) {
    return (
      <div>
        <h2 className="text-2xl font-bold mb-4">Trending Now</h2>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-3 gap-4">
          {[...Array(6)].map((_, index) => (
            <Card key={index} className="overflow-hidden border-0 bg-transparent">
              <div className="relative aspect-[3/4] rounded-md overflow-hidden">
                <Skeleton className="h-full w-full" />
              </div>
            </Card>
          ))}
        </div>
      </div>
    )
  }

  return (
    <div>
      <h2 className="text-2xl font-bold mb-4">Trending Now</h2>
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-3 gap-4">
        {trendingAnime.map((anime) => (
          <Link href={`/anime/${anime.id}`} key={anime.id}>
            <Card className="overflow-hidden border-0 bg-transparent hover:scale-105 transition-transform duration-200">
              <div className="relative aspect-[3/4] rounded-md overflow-hidden">
                <Image src={anime.coverImage || "/placeholder.svg"} alt={anime.title} fill className="object-cover" />
                <div className="absolute top-2 left-2 bg-black/70 text-white text-xs px-2 py-1 rounded">
                  EP {anime.currentEpisode}
                </div>
                <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-3">
                  <div className="text-xs text-white/80 mb-1">
                    {anime.format} • {anime.status}
                  </div>
                  <h3 className="text-white font-medium line-clamp-2">{anime.title}</h3>
                </div>
              </div>
            </Card>
          </Link>
        ))}
      </div>
    </div>
  )
}

