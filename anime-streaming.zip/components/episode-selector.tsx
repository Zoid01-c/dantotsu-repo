"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import Link from "next/link"

interface EpisodeSelectorProps {
  animeId: string
  currentEpisode: number
  totalEpisodes: number
}

export default function EpisodeSelector({ animeId, currentEpisode, totalEpisodes }: EpisodeSelectorProps) {
  const [selectedRange, setSelectedRange] = useState<"all" | "current">("current")

  const episodes = Array.from({ length: totalEpisodes }, (_, i) => i + 1)

  const displayedEpisodes =
    selectedRange === "all" ? episodes : episodes.filter((ep) => Math.abs(ep - currentEpisode) <= 2)

  return (
    <div>
      <div className="flex gap-2 mb-3">
        <Button
          variant={selectedRange === "current" ? "default" : "outline"}
          size="sm"
          onClick={() => setSelectedRange("current")}
        >
          Current
        </Button>
        <Button
          variant={selectedRange === "all" ? "default" : "outline"}
          size="sm"
          onClick={() => setSelectedRange("all")}
        >
          All Episodes
        </Button>
      </div>

      <div className="grid grid-cols-4 sm:grid-cols-6 md:grid-cols-8 lg:grid-cols-10 gap-2">
        {displayedEpisodes.map((episode) => (
          <Button
            key={episode}
            variant={episode === currentEpisode ? "default" : "outline"}
            className={episode === currentEpisode ? "bg-purple-600 hover:bg-purple-700" : ""}
            asChild
          >
            <Link href={`/watch/${animeId}/${episode}`}>{episode}</Link>
          </Button>
        ))}
      </div>
    </div>
  )
}

