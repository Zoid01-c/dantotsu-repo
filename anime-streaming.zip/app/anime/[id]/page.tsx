"use client"

import { useState, useEffect } from "react"
import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ChevronLeft, Play } from "lucide-react"
import { ThemeToggle } from "@/components/theme-toggle"
import EpisodeSelector from "@/components/episode-selector"
import RelatedAnime from "@/components/related-anime"
import { Skeleton } from "@/components/ui/skeleton"

interface AnimeDetails {
  id: number
  title: string
  description: string
  coverImage: string
  bannerImage: string
  format: string
  status: string
  episodes: number
  currentEpisode: number
  year: number
  genres: string[]
  studios: string[]
  duration: string
  score: number
}

export default function AnimePage({ params }: { params: { id: string } }) {
  const [animeDetails, setAnimeDetails] = useState<AnimeDetails | null>(null)
  const [loading, setLoading] = useState(true)

  const animeId = Number.parseInt(params.id)

  useEffect(() => {
    async function fetchAnimeDetails() {
      try {
        const response = await fetch(`/api/anime/${animeId}`)
        const data = await response.json()

        if (data.anime) {
          setAnimeDetails(data.anime)
        }
      } catch (error) {
        console.error("Error fetching anime details:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchAnimeDetails()
  }, [animeId])

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <div className="relative h-[400px] overflow-hidden">
          <Skeleton className="h-full w-full" />

          <div className="container mx-auto px-4 relative z-20">
            <div className="flex justify-between items-center pt-6">
              <Skeleton className="h-10 w-32" />
              <ThemeToggle />
            </div>
          </div>
        </div>

        <div className="container mx-auto px-4 py-6">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 -mt-32 relative z-20">
            <div className="md:col-span-1">
              <Skeleton className="aspect-[3/4] rounded-lg shadow-xl" />
            </div>

            <div className="md:col-span-3">
              <Skeleton className="h-10 w-3/4 mb-2" />
              <Skeleton className="h-4 w-full mb-6" />
              <Skeleton className="h-10 w-40 mb-8" />

              <Skeleton className="h-6 w-32 mb-3" />
              <div className="grid grid-cols-4 sm:grid-cols-6 md:grid-cols-8 gap-2 mb-8">
                {[...Array(10)].map((_, index) => (
                  <Skeleton key={index} className="h-10 w-full" />
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    )
  }

  if (!animeDetails) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold mb-2">Anime not found</h1>
          <p className="text-muted-foreground mb-4">The anime you're looking for doesn't exist or has been removed.</p>
          <Button asChild>
            <Link href="/">Go back to home</Link>
          </Button>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="relative h-[400px] overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-t from-background via-background/80 to-transparent z-10" />
        <Image
          src={animeDetails.bannerImage || animeDetails.coverImage || "/placeholder.svg?height=500&width=1000"}
          alt={animeDetails.title}
          fill
          className="object-cover"
          priority
        />

        <div className="container mx-auto px-4 relative z-20">
          <div className="flex justify-between items-center pt-6">
            <Button variant="ghost" asChild>
              <Link href="/">
                <ChevronLeft className="mr-2 h-4 w-4" />
                Back to Home
              </Link>
            </Button>
            <ThemeToggle />
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-6">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 -mt-32 relative z-20">
          <div className="md:col-span-1">
            <div className="relative aspect-[3/4] rounded-lg overflow-hidden shadow-xl">
              <Image
                src={animeDetails.coverImage || "/placeholder.svg"}
                alt={animeDetails.title}
                fill
                className="object-cover"
              />
            </div>

            <div className="mt-4 space-y-2">
              <div className="flex flex-wrap gap-2">
                {animeDetails.genres.map((genre) => (
                  <span key={genre} className="px-2 py-1 bg-primary/10 text-primary rounded text-xs">
                    {genre}
                  </span>
                ))}
              </div>

              <div className="grid grid-cols-2 gap-2 text-sm">
                <div className="text-muted-foreground">Studio</div>
                <div>{animeDetails.studios.join(", ") || "Unknown"}</div>

                <div className="text-muted-foreground">Status</div>
                <div>{animeDetails.status}</div>

                <div className="text-muted-foreground">Episodes</div>
                <div>{animeDetails.episodes || "Unknown"}</div>

                <div className="text-muted-foreground">Duration</div>
                <div>{animeDetails.duration}</div>

                <div className="text-muted-foreground">Score</div>
                <div>{animeDetails.score ? `${animeDetails.score / 10} / 10` : "N/A"}</div>
              </div>
            </div>
          </div>

          <div className="md:col-span-3">
            <h1 className="text-3xl font-bold mb-2">{animeDetails.title}</h1>
            <p className="text-muted-foreground mb-6">{animeDetails.description}</p>

            <Button asChild className="bg-purple-600 hover:bg-purple-700 mb-8">
              <Link href={`/watch/${animeDetails.id}/${animeDetails.currentEpisode}`}>
                <Play className="mr-2 h-4 w-4" />
                Watch Episode {animeDetails.currentEpisode}
              </Link>
            </Button>

            <div className="mb-8">
              <h2 className="text-xl font-semibold mb-3">Episodes</h2>
              <EpisodeSelector
                animeId={animeDetails.id.toString()}
                currentEpisode={animeDetails.currentEpisode}
                totalEpisodes={animeDetails.episodes || 12}
              />
            </div>

            <div>
              <h2 className="text-xl font-semibold mb-3">Related Anime</h2>
              <RelatedAnime animeId={animeDetails.id} />
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

