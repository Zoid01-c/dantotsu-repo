"use client"

import { useState, useEffect } from "react"
import { VideoPlayer } from "@/components/video-player"
import { Button } from "@/components/ui/button"
import { ChevronLeft, Heart, Share2 } from "lucide-react"
import Link from "next/link"
import EpisodeSelector from "@/components/episode-selector"
import RelatedAnime from "@/components/related-anime"
import { ThemeToggle } from "@/components/theme-toggle"
import type { VideoSource, SubtitleTrack, SourceProvider } from "@/lib/sources"
import { Skeleton } from "@/components/ui/skeleton"

interface AnimeDetails {
  id: number
  title: string
  description: string
  episodes: number
  currentEpisode: number
}

export default function WatchPage({ params }: { params: { id: string; episode: string } }) {
  const [animeDetails, setAnimeDetails] = useState<AnimeDetails | null>(null)
  const [videoSources, setVideoSources] = useState<VideoSource[]>([])
  const [subtitles, setSubtitles] = useState<SubtitleTrack[]>([])
  const [sourceInfo, setSourceInfo] = useState<{ id: string; name: string } | undefined>()
  const [availableSources, setAvailableSources] = useState<SourceProvider[]>([])
  const [loading, setLoading] = useState(true)
  const [loadingVideo, setLoadingVideo] = useState(true)

  const animeId = Number.parseInt(params.id)
  const episodeNumber = Number.parseInt(params.episode)

  // Fetch anime details
  useEffect(() => {
    async function fetchAnimeDetails() {
      try {
        const response = await fetch(`/api/anime/${animeId}`)
        const data = await response.json()

        if (data.anime) {
          setAnimeDetails(data.anime)
        }
      } catch (error) {
        console.error("Error fetching anime details:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchAnimeDetails()
  }, [animeId])

  // Fetch available sources
  useEffect(() => {
    async function fetchAvailableSources() {
      if (!animeDetails) return

      try {
        const response = await fetch(`/api/sources?animeId=${animeId}&title=${encodeURIComponent(animeDetails.title)}`)
        const data = await response.json()

        if (data.sources) {
          setAvailableSources(data.sources)
          // Use the first source by default
          if (data.sources.length > 0 && !sourceInfo) {
            fetchVideoSources(data.sources[0].id)
          }
        }
      } catch (error) {
        console.error("Error fetching available sources:", error)
      }
    }

    if (animeDetails) {
      fetchAvailableSources()
    }
  }, [animeDetails, animeId, sourceInfo])

  // Function to fetch video sources from a specific provider
  const fetchVideoSources = async (sourceId: string) => {
    setLoadingVideo(true)

    try {
      const response = await fetch(`/api/video?animeId=${animeId}&episode=${episodeNumber}&source=${sourceId}`)
      const data = await response.json()

      if (data.sources) {
        setVideoSources(data.sources)
        setSubtitles(data.subtitles || [])
        setSourceInfo(data.sourceInfo)
      }
    } catch (error) {
      console.error("Error fetching video sources:", error)
    } finally {
      setLoadingVideo(false)
    }
  }

  // Handle source change
  const handleSourceChange = (sourceId: string) => {
    fetchVideoSources(sourceId)
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <div className="container mx-auto px-4 py-6">
          <div className="flex justify-between items-center mb-4">
            <Skeleton className="h-10 w-32" />
            <ThemeToggle />
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
            <div className="lg:col-span-3">
              <div className="rounded-lg overflow-hidden bg-black">
                <Skeleton className="aspect-video w-full" />
              </div>

              <div className="mt-4">
                <Skeleton className="h-8 w-64 mb-2" />
                <Skeleton className="h-4 w-32" />
              </div>
            </div>

            <div className="lg:col-span-1">
              <Skeleton className="h-6 w-48 mb-3" />
              <div className="space-y-3">
                {[...Array(4)].map((_, index) => (
                  <Skeleton key={index} className="h-24 w-full" />
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    )
  }

  if (!animeDetails) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold mb-2">Anime not found</h1>
          <p className="text-muted-foreground mb-4">The anime you're looking for doesn't exist or has been removed.</p>
          <Button asChild>
            <Link href="/">Go back to home</Link>
          </Button>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-6">
        <div className="flex justify-between items-center mb-4">
          <Button variant="ghost" asChild>
            <Link href={`/anime/${animeId}`}>
              <ChevronLeft className="mr-2 h-4 w-4" />
              Back to Anime
            </Link>
          </Button>
          <ThemeToggle />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          <div className="lg:col-span-3">
            <div className="rounded-lg overflow-hidden bg-black">
              {loadingVideo ? (
                <div className="aspect-video w-full flex items-center justify-center bg-card">
                  <div className="h-12 w-12 rounded-full border-4 border-t-transparent border-purple-600 animate-spin"></div>
                </div>
              ) : (
                <VideoPlayer
                  sources={videoSources}
                  subtitles={subtitles}
                  sourceInfo={sourceInfo}
                  onSourceChange={handleSourceChange}
                  availableSources={availableSources}
                />
              )}
            </div>

            <div className="mt-4 flex justify-between items-center">
              <div>
                <h1 className="text-2xl font-bold">{animeDetails.title}</h1>
                <p className="text-muted-foreground">Episode {episodeNumber}</p>
              </div>
              <div className="flex gap-2">
                <Button variant="outline" size="icon">
                  <Heart className="h-4 w-4" />
                </Button>
                <Button variant="outline" size="icon">
                  <Share2 className="h-4 w-4" />
                </Button>
              </div>
            </div>

            <div className="mt-6">
              <h2 className="text-xl font-semibold mb-3">Episodes</h2>
              <EpisodeSelector
                animeId={animeId.toString()}
                currentEpisode={episodeNumber}
                totalEpisodes={animeDetails.episodes || 12}
              />
            </div>
          </div>

          <div className="lg:col-span-1">
            <h2 className="text-xl font-semibold mb-3">Related Anime</h2>
            <RelatedAnime animeId={animeId} />
          </div>
        </div>
      </div>
    </div>
  )
}

