import { VideoPlayer } from "@/components/video-player"
import { Button } from "@/components/ui/button"
import { ChevronLeft, Heart, Share2 } from "lucide-react"
import Link from "next/link"
import EpisodeSelector from "@/components/episode-selector"
import RelatedAnime from "@/components/related-anime"

export default function WatchPage({ params }: { params: { anime: string; episode: string } }) {
  // In a real app, you would fetch anime details and video sources here
  const animeTitle = params.anime
    .split("-")
    .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
    .join(" ")
  const episodeNumber = params.episode

  // This would be fetched from an API in a real implementation
  const videoSources = [
    {
      src: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
      type: "video/mp4",
      quality: "1080p",
    },
  ]

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-6">
        <Button variant="ghost" asChild className="mb-4">
          <Link href="/">
            <ChevronLeft className="mr-2 h-4 w-4" />
            Back to Home
          </Link>
        </Button>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          <div className="lg:col-span-3">
            <div className="rounded-lg overflow-hidden bg-black">
              <VideoPlayer sources={videoSources} />
            </div>

            <div className="mt-4 flex justify-between items-center">
              <div>
                <h1 className="text-2xl font-bold">{animeTitle}</h1>
                <p className="text-muted-foreground">Episode {episodeNumber}</p>
              </div>
              <div className="flex gap-2">
                <Button variant="outline" size="icon">
                  <Heart className="h-4 w-4" />
                </Button>
                <Button variant="outline" size="icon">
                  <Share2 className="h-4 w-4" />
                </Button>
              </div>
            </div>

            <div className="mt-6">
              <h2 className="text-xl font-semibold mb-3">Episodes</h2>
              <EpisodeSelector
                animeId={params.anime}
                currentEpisode={Number.parseInt(episodeNumber)}
                totalEpisodes={12}
              />
            </div>
          </div>

          <div className="lg:col-span-1">
            <h2 className="text-xl font-semibold mb-3">Related Anime</h2>
            <RelatedAnime />
          </div>
        </div>
      </div>
    </div>
  )
}

