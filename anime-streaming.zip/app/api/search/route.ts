import { NextResponse } from "next/server"
import { searchAnime } from "@/lib/anilist"

export async function GET(request: Request) {
  const url = new URL(request.url)
  const query = url.searchParams.get("q")

  if (!query) {
    return NextResponse.json({ error: "Missing search query" }, { status: 400 })
  }

  try {
    const results = await searchAnime(query)
    return NextResponse.json({ results })
  } catch (error) {
    console.error("Error searching anime:", error)
    return NextResponse.json({ error: "Failed to search anime" }, { status: 500 })
  }
}

