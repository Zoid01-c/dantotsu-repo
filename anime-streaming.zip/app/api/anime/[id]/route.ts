import { NextResponse } from "next/server"
import { getAnimeDetails } from "@/lib/anilist"

export async function GET(request: Request, { params }: { params: { id: string } }) {
  try {
    const animeId = Number.parseInt(params.id)
    if (isNaN(animeId)) {
      return NextResponse.json({ error: "Invalid anime ID" }, { status: 400 })
    }

    const animeDetails = await getAnimeDetails(animeId)
    return NextResponse.json({ anime: animeDetails })
  } catch (error) {
    console.error("Error fetching anime details:", error)
    return NextResponse.json({ error: "Failed to fetch anime details" }, { status: 500 })
  }
}

