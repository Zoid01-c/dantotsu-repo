import { NextResponse } from "next/server"
import { EXTERNAL_SOURCES } from "@/lib/sources"

// This endpoint would check which sources have the requested anime
export async function GET(request: Request) {
  const url = new URL(request.url)
  const animeId = url.searchParams.get("animeId")
  const title = url.searchParams.get("title")

  if (!animeId || !title) {
    return NextResponse.json({ error: "Missing animeId or title parameter" }, { status: 400 })
  }

  try {
    // In a real implementation, you would:
    // 1. Check each source to see if they have this anime
    // 2. Return only the sources that have it

    // For demo purposes, we'll return all sources
    const availableSources = EXTERNAL_SOURCES

    return NextResponse.json({ sources: availableSources })
  } catch (error) {
    console.error("Error fetching available sources:", error)
    return NextResponse.json({ error: "Failed to fetch available sources" }, { status: 500 })
  }
}

