import { NextResponse } from "next/server"
import { getTrendingAnime } from "@/lib/anilist"

export async function GET() {
  try {
    const trendingAnime = await getTrendingAnime()
    return NextResponse.json({ anime: trendingAnime })
  } catch (error) {
    console.error("Error fetching trending anime:", error)
    return NextResponse.json({ error: "Failed to fetch trending anime" }, { status: 500 })
  }
}

